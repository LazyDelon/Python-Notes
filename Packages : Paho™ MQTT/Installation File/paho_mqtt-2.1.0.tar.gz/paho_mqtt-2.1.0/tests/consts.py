import pathlib

tests_path = pathlib.Path(__file__).parent
lib_path = tests_path.parent
ssl_path = tests_path / "ssl"
