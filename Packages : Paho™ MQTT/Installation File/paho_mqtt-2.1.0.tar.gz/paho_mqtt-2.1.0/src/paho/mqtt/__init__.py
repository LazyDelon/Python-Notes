__version__ = "2.1.0"


class MQTTException(Exception):
    pass
